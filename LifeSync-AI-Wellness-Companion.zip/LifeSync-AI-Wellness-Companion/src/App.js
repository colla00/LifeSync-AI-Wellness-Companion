import React from 'react';

function App() {
    return (
        <div>
            <h1>LifeSync: AI Wellness Companion</h1>
            <p>Your personal AI wellness companion for real-time mood tracking and coaching.</p>
        </div>
    );
}

export default App;
